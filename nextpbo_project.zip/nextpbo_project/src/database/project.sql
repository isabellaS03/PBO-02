/*
SQLyog Community v12.3.2 (64 bit)
MySQL - 10.1.13-MariaDB : Database - project
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`project` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `project`;

/*Table structure for table `ib` */

DROP TABLE IF EXISTS `ib`;

CREATE TABLE `ib` (
  `ID_IB` int(11) NOT NULL,
  `NIM` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `angkatan` varchar(50) NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `keberangkatan` varchar(50) NOT NULL,
  `kembali` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Request',
  PRIMARY KEY (`ID_IB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ib` */

insert  into `ib`(`ID_IB`,`NIM`,`nama`,`angkatan`,`prodi`,`keberangkatan`,`kembali`,`keterangan`,`status`) values 
(1,11315017,'Leo Pakpahan','2016','D3 Teknik Informatika','2017-01-01 17:00','2017-01-03 20:00','zzzzz ','ACCEPT'),
(3,11315013,'Yosua','2015','D3 Teknik Informatika','2016-23-12 17:00','2016-28-12 17:00','Main-main','Request');

/*Table structure for table `ika` */

DROP TABLE IF EXISTS `ika`;

CREATE TABLE `ika` (
  `ID_IKA` int(11) NOT NULL,
  `NIM` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `keluar` varchar(50) NOT NULL,
  `kembali` varchar(50) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY (`ID_IKA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ika` */

insert  into `ika`(`ID_IKA`,`NIM`,`nama`,`prodi`,`keluar`,`kembali`,`keterangan`) values 
(1,11315013,'Yosua Sirait','D3 Teknik Informatika','2016-12-21 13:00','2016-12-21 15:00','Ke Balige membeli peralatan');

/*Table structure for table `inventory` */

DROP TABLE IF EXISTS `inventory`;

CREATE TABLE `inventory` (
  `idInventory` int(11) NOT NULL,
  `namaInventory` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  PRIMARY KEY (`idInventory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `inventory` */

insert  into `inventory`(`idInventory`,`namaInventory`,`jumlah`) values 
(1,'Sapu','4'),
(2,'Kain Pel','3'),
(3,'Vortex','8'),
(4,'Clinx','10'),
(5,'Sekop','3'),
(6,'Sapu Ijuk','3'),
(7,'Lap','3');

/*Table structure for table `jadwalkurve` */

DROP TABLE IF EXISTS `jadwalkurve`;

CREATE TABLE `jadwalkurve` (
  `idKurve` int(11) NOT NULL,
  `tempatKurve` varchar(100) NOT NULL,
  `hari` varchar(100) NOT NULL,
  `idMahasiswa` varchar(100) NOT NULL,
  PRIMARY KEY (`idKurve`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `jadwalkurve` */

insert  into `jadwalkurve`(`idKurve`,`tempatKurve`,`hari`,`idMahasiswa`) values 
(1,'Kamar','Sabtu','11315002'),
(2,'Kamar Mandi','Senin','11315013'),
(3,'Toilet','Sabtu','11315017');

/*Table structure for table `mahasiswa` */

DROP TABLE IF EXISTS `mahasiswa`;

CREATE TABLE `mahasiswa` (
  `NIM` int(11) NOT NULL,
  `Nama_Mahasiswa` varchar(100) NOT NULL,
  PRIMARY KEY (`NIM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mahasiswa` */

insert  into `mahasiswa`(`NIM`,`Nama_Mahasiswa`) values 
(7,'Putri'),
(11315002,'Putri Matondang'),
(11315013,'Yosua Sirait');

/*Table structure for table `obat` */

DROP TABLE IF EXISTS `obat`;

CREATE TABLE `obat` (
  `idObat` int(11) NOT NULL,
  `namaObat` varchar(100) NOT NULL,
  `aturanPakai` varchar(100) NOT NULL,
  PRIMARY KEY (`idObat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `obat` */

/*Table structure for table `pengaduan` */

DROP TABLE IF EXISTS `pengaduan`;

CREATE TABLE `pengaduan` (
  `idPengaduan` int(11) NOT NULL,
  `idMahasiswa` int(11) NOT NULL,
  `waktu` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pengaduan` */

insert  into `pengaduan`(`idPengaduan`,`idMahasiswa`,`waktu`) values 
(12,1,'asda'),
(2,3,'3'),
(4,2,'awdawdw');

/*Table structure for table `pengumuman` */

DROP TABLE IF EXISTS `pengumuman`;

CREATE TABLE `pengumuman` (
  `idPengumuman` int(11) NOT NULL,
  `judulPengumuman` varchar(100) NOT NULL,
  `tujuanPengumuman` varchar(100) NOT NULL,
  `pembuatPengumuman` varchar(100) NOT NULL,
  PRIMARY KEY (`idPengumuman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pengumuman` */

insert  into `pengumuman`(`idPengumuman`,`judulPengumuman`,`tujuanPengumuman`,`pembuatPengumuman`) values 
(1,'Mencuri','ashjdk','jashdkja');

/*Table structure for table `pengurus` */

DROP TABLE IF EXISTS `pengurus`;

CREATE TABLE `pengurus` (
  `ID_Pengurus` int(11) NOT NULL,
  `Nama_Pengurus` varchar(60) NOT NULL,
  PRIMARY KEY (`ID_Pengurus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pengurus` */

insert  into `pengurus`(`ID_Pengurus`,`Nama_Pengurus`) values 
(1,'Leo'),
(2,'asdadasd');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `ID_Staff` int(11) NOT NULL,
  `Nama_Staff` varchar(100) NOT NULL,
  PRIMARY KEY (`ID_Staff`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`ID_Staff`,`Nama_Staff`) values 
(1,'Nelson'),
(2,'Suprando'),
(4,'dsadadas');

/*Table structure for table `tblogin` */

DROP TABLE IF EXISTS `tblogin`;

CREATE TABLE `tblogin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `typeuser` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblogin` */

insert  into `tblogin`(`username`,`password`,`typeuser`) values 
('pengurus','pengurus','1'),
('mahasiswa','mahasiswa','2'),
('staf','staf','3');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
