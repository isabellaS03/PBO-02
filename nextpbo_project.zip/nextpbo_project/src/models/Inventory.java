/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
public class Inventory {
    private String idInventory,namaInventory,jumlah;

    public void setIdInventory(String idInventory) {
        this.idInventory = idInventory;
    }

    public void setNamaInventory(String namaInventory) {
        this.namaInventory = namaInventory;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getIdInventory() {
        return idInventory;
    }

    public String getNamaInventory() {
        return namaInventory;
    }

    public String getJumlah() {
        return jumlah;
    }

    
}
