/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
public class Kurve {
    private String idKurve,tempatKurve,hari,idMahasiswa;

    public void setIdKurve(String idKurve) {
        this.idKurve = idKurve;
    }

    public void setTempatKurve(String tempatKurve) {
        this.tempatKurve = tempatKurve;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public void setIdMahasiswa(String idMahasiswa) {
        this.idMahasiswa = idMahasiswa;
    }

    public String getIdKurve() {
        return idKurve;
    }

    public String getTempatKurve() {
        return tempatKurve;
    }

    public String getHari() {
        return hari;
    }

    public String getIdMahasiswa() {
        return idMahasiswa;
    }

    
}
