/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
public class Pelanggaran {
    private String idPelanggaran,peraturan,idMahasiswa,Sanksi;

    public String getIdPelanggaran() {
        return idPelanggaran;
    }

    public void setIdPelanggaran(String idPelanggaran) {
        this.idPelanggaran = idPelanggaran;
    }

    public String getPeraturan() {
        return peraturan;
    }

    public void setPeraturan(String peraturan) {
        this.peraturan = peraturan;
    }

    public String getIdMahasiswa() {
        return idMahasiswa;
    }

    public void setIdMahasiswa(String idMahasiswa) {
        this.idMahasiswa = idMahasiswa;
    }

    public String getSanksi() {
        return Sanksi;
    }

    public void setSanksi(String Sanksi) {
        this.Sanksi = Sanksi;
    }

    
}
