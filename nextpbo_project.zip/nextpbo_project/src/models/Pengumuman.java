/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
public class Pengumuman {
    private String idPengumuman,judulPengumuman, tujuanPengumuman, pembuatPengumuman;

    public String getIdPengumuman() {
        return idPengumuman;
    }

    public void setIdPengumuman(String idPengumuman) {
        this.idPengumuman = idPengumuman;
    }

    public String getJudulPengumuman() {
        return judulPengumuman;
    }

    public void setJudulPengumuman(String judulPengumuman) {
        this.judulPengumuman = judulPengumuman;
    }

    public String getTujuanPengumuman() {
        return tujuanPengumuman;
    }

    public void setTujuanPengumuman(String tujuanPengumuman) {
        this.tujuanPengumuman = tujuanPengumuman;
    }

    public String getPembuatPengumuman() {
        return pembuatPengumuman;
    }

    public void setPembuatPengumuman(String pembuatPengumuman) {
        this.pembuatPengumuman = pembuatPengumuman;
    }
}
