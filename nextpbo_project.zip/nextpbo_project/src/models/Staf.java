/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;
/**
 *
 * @author Putri Matondang
 */
public class Staf {
    private String idStaf,namaStaf;

    public String getIdStaf() {
        return idStaf;
    }

    public void setIdStaf(String idStaf) {
        this.idStaf = idStaf;
    }

    public String getNamaStaf() {
        return namaStaf;
    }

    public void setNamaStaf(String namaStaf) {
        this.namaStaf = namaStaf;
    }
}
