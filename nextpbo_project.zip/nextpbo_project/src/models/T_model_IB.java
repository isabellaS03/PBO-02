/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_IB extends AbstractTableModel {
    private final List<ib> listIB;

    public T_model_IB(List<ib> list) {
        this.listIB = list;
    }

    @Override
    public int getRowCount() {
        return listIB.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listIB.get(rowIndex).getID_IB();
            case 1:
                return listIB.get(rowIndex).getNIM();
            case 2:
                return listIB.get(rowIndex).getNama();
            case 3:
                return listIB.get(rowIndex).getKeberangkatan();
            case 4:
                return listIB.get(rowIndex).getKembali();
            case 5:
                return listIB.get(rowIndex).getKeterangan();            
            case 6:
                return listIB.get(rowIndex).getStatus();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {            
            case 0:
                return "ID_IB";
            case 1:
                return "NIM";
            case 2:
                return "NAMA";
            case 3:
                return "KEBERANGKATAN";
            case 4:
                return "KEMBALI";
            case 5:
                return "KETERANGAN";   
            case 6:
                return "STATUS";   
            default:
                return null;
        }
    }
}