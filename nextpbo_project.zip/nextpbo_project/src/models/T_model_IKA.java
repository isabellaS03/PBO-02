/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_IKA extends AbstractTableModel {
    private final List<ika> listIKA;

    public T_model_IKA(List<ika> list) {
        this.listIKA = list;
    }

    @Override
    public int getRowCount() {
        return listIKA.size();
    }

    @Override
    public int getColumnCount() {
        return 8;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listIKA.get(rowIndex).getID_IKA();
            case 1:
                return listIKA.get(rowIndex).getNIM();
            case 2:
                return listIKA.get(rowIndex).getNama();
            case 3:
                return listIKA.get(rowIndex).getProdi();
            case 4:
                return listIKA.get(rowIndex).getKeluar();              
            case 5:
                return listIKA.get(rowIndex).getKembali();
            case 6:
                return listIKA.get(rowIndex).getKeterangan();  
                case 7:
                return listIKA.get(rowIndex).getStatus();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "ID_IKA";
            case 1:
                return "NIM";
            case 2:
                return "NAMA";
            case 3:
                return "PRODI";
            case 4:
                return "KELUAR";                
            case 5:
                return "KEMBALI";                
            case 6:
                return "KETERANGAN";     
                case 7:
                return "STATUS"; 
            default:
                return null;
        }
    }
}