/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Putri Matondang
 */
public class T_model_Inventory extends AbstractTableModel {
    private List<Inventory> listinventory;

    public T_model_Inventory(List<Inventory> listinventory) {
        this.listinventory = listinventory;
    }

    public int getRowCount() {
        return listinventory.size();
    }

    public int getColumnCount() {
        return 3;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listinventory.get(rowIndex).getIdInventory();
            case 1:
                return listinventory.get(rowIndex).getNamaInventory();
            case 2:
                return listinventory.get(rowIndex).getJumlah();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Inventory";
            case 1:
                return "Nama Inventory";
            case 2:
                return "Jumlah";
            default:
                return null;
        }
    }
}
