/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_Kurve extends AbstractTableModel {
    private List<Kurve> listkurve;

    public T_model_Kurve(List<Kurve> list) {
        this.listkurve = list;
    }

    public int getRowCount() {
        return listkurve.size();
    }

    public int getColumnCount() {
        return 4;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listkurve.get(rowIndex).getIdKurve();
            case 1:
                return listkurve.get(rowIndex).getTempatKurve();
            case 2:
                return listkurve.get(rowIndex).getHari();
            case 3:
                return listkurve.get(rowIndex).getIdMahasiswa();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Kurve";
            case 1:
                return "Tempat";
            case 2:
                return "Hari";
                case 3:
                return "Kode Mahasiswa";
            default:
                return null;
        }
    }
}