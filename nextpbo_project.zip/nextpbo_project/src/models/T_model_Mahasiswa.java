/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import views.Form_Staf;

public class T_model_Mahasiswa extends AbstractTableModel {
    private List<Mahasiswa> listmahasiswa;

    public T_model_Mahasiswa(List<Mahasiswa> list) {
        this.listmahasiswa = list;
    }

   

    public int getRowCount() {
        return listmahasiswa.size();
    }

    public int getColumnCount() {
        return 2;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listmahasiswa.get(rowIndex).getIdMahasiswa();
            case 1:
                return listmahasiswa.get(rowIndex).getNamaMahasiswa();
           
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Mahasiswa";
            case 1:
                return "Nama_Mahasiswa";
          
            default:
                return null;
        }
    }
}

