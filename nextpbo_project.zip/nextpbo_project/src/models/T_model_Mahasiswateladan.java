/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import views.Form_Staf;


/**
 *
 * @author Putri Matondang
 */
public class T_model_Mahasiswateladan extends AbstractTableModel {
        private List<teladan> listteladan;

    public T_model_Mahasiswateladan(List<teladan> list) {
        this.listteladan = list;
    }

    

    public int getRowCount() {
        return listteladan.size();
    }

    public int getColumnCount() {
        return 2;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listteladan.get(rowIndex).getIdTeladan();
            case 1:
                return listteladan.get(rowIndex).getNamaTeladan();
           
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "NIMT";
            case 1:
                return "Nama_Mahasiswateladan";
          
            default:
                return null;
        }
    }

    
    
}
