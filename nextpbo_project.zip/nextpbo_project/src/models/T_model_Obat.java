/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_Obat extends AbstractTableModel {
    private List<Obat> list;

    public T_model_Obat(List<Obat> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 3;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return list.get(rowIndex).getIdObat();
            case 1:
                return list.get(rowIndex).getNamaObat();
            case 2:
                return list.get(rowIndex).getAturanPakai();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Obat";
            case 1:
                return "NamaObat";
            case 2:
                return "Aturan Pakai";
            default:
                return null;
        }
    }
}