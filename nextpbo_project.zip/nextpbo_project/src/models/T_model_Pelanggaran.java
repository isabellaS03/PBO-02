/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_Pelanggaran extends AbstractTableModel {
    private List<Pelanggaran> listpelanggaran;

    public T_model_Pelanggaran(List<Pelanggaran> list) {
        this.listpelanggaran = list;
    }

    public int getRowCount() {
        return listpelanggaran.size();
    }

    public int getColumnCount() {
        return 4;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listpelanggaran.get(rowIndex).getIdPelanggaran();
            case 1:
                return listpelanggaran.get(rowIndex).getPeraturan();
            case 2:
                return listpelanggaran.get(rowIndex).getIdMahasiswa();
            case 3:
                return listpelanggaran.get(rowIndex).getSanksi();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id Pelanggaran";
            case 1:
                return "Peraturan";
            case 2:
                return "Id Mahasiswa";
                case 3:
                return "Sanksi";
            default:
                return null;
        }
    }
}