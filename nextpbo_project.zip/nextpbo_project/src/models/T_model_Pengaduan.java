/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Putri Matondang
 */
public class T_model_Pengaduan extends AbstractTableModel {

    private List<Pengaduan> listpengaduan;

    public T_model_Pengaduan(List<Pengaduan> listpengaduan) {
        this.listpengaduan = listpengaduan;
    }

    public int getRowCount() {
        return listpengaduan.size();
    }

    public int getColumnCount() {
        return 3;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listpengaduan.get(rowIndex).getIdPengaduan();
            case 1:
                return listpengaduan.get(rowIndex).getIdMahasiswa();
            case 2:
                return listpengaduan.get(rowIndex).getWaktu();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id Pengaduan";
            case 1:
                return "Id Mahasiswa";
            case 2:
                return "Waktu";
            default:
                return null;
        }
    }
}
