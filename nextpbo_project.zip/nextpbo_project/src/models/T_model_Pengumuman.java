/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;
public class T_model_Pengumuman extends AbstractTableModel {
    private List<Pengumuman> listpengumuman;

    public T_model_Pengumuman(List<Pengumuman> list) {
        this.listpengumuman = list;
    }

    public int getRowCount() {
        return listpengumuman.size();
    }

    public int getColumnCount() {
        return 4;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listpengumuman.get(rowIndex).getIdPengumuman();
            case 1:
                return listpengumuman.get(rowIndex).getJudulPengumuman();
            case 2:
                return listpengumuman.get(rowIndex).getTujuanPengumuman();
            case 3:
                return listpengumuman.get(rowIndex).getPembuatPengumuman();
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Pengumuman";
            case 1:
                return "Judul Pengumuman";
            case 2:
                return "Tujuan Pengumuman";
            case 3:
                return "Pembuat Pengumuman";
          
            default:
                return null;
        }
    }
}


