/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;
/**
 *
 * @author Putri Matondang
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class T_model_Staf extends AbstractTableModel {
    private List<Staf> liststaf;

    public T_model_Staf(List<Staf> list) {
        this.liststaf = list;
    }

    public int getRowCount() {
        return liststaf.size();
    }

    public int getColumnCount() {
        return 2;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return liststaf.get(rowIndex).getIdStaf();
            case 1:
                return liststaf.get(rowIndex).getNamaStaf();
           
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Staf";
            case 1:
                return "Nama Staf";
          
            default:
                return null;
        }
    }
}
