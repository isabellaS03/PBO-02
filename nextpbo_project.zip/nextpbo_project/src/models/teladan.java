/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Putri Matondang
 */
public class teladan {
    private String  idTeladan, namaTeladan;

    public String getIdTeladan() {
        return idTeladan;
    }

    public void setIdTeladan(String idTeladan) {
        this.idTeladan = idTeladan;
    }

    public String getNamaTeladan() {
        return namaTeladan;
    }

    public void setNamaTeladan(String namaTeladan) {
        this.namaTeladan = namaTeladan;
    }
}

   