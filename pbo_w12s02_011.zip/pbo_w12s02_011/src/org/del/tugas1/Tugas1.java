/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.tugas1;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
 *
 * @author Isabella
 */
public class Tugas1 {

    public static void main(String[] args) throws IOException {
        String file = "tugas1.txt";
        BufferedReader isibuffer = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Masukan Nama Anda : ");
        String ah = isibuffer.readLine();
        System.out.print("Masukan Alamat Anda : ");
        String da = isibuffer.readLine();
        System.out.print("Masukan Nomor Telepon : ");
        String df = isibuffer.readLine();
        FileOutputStream tulisfile;
        tulisfile = new FileOutputStream(file);
        new PrintStream(tulisfile).print("Halo " +ah +",");
        new PrintStream(tulisfile).print("alamatmu di " + da);
        new PrintStream(tulisfile).println();
        new PrintStream(tulisfile).print("Nomor teleponmu adalah " +df);
        new PrintStream(tulisfile).println();
        tulisfile.close();
    }
}
