/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.tugas2;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Scanner;

/**
 *
 * @author Isabella
 */
public class Tugas2 {

    public static void main(String[] args) throws IOException {
        float rate;
        int jumlah = 0;
        String file = "tugas2.txt";
        BufferedReader isibuffer = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Masukan Nama : ");
        String ah = isibuffer.readLine();
        Scanner hitung = new Scanner(System.in);
        System.out.print("Jumlah matakuliah: ");
        int a = hitung.nextInt();
        for (int i = 1; i <= a; i++) {
            try {
                Scanner hitungrata = new Scanner(System.in);
                System.out.print("MK" + i + ": ");
                int b = hitungrata.nextInt();
                jumlah += b;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        rate = (float) jumlah / (float) a;
        FileOutputStream tulisfile;
        tulisfile = new FileOutputStream(file);
        new PrintStream(tulisfile).print(ah + ", ");
        new PrintStream(tulisfile).print("Nilai rata-rata dari " + a + " matakuliah yang kamu masukkan adalah " + rate);
        new PrintStream(tulisfile).println();

        tulisfile.close();
    }
}
