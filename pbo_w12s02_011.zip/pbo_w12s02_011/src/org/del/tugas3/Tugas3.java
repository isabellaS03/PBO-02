/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.tugas3;

/**
 *
 * @author Isabella
 */
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Tugas3{

    public static void main(String[] args) {

        File file = new File("mhs.txt");
        FileInputStream fIS = null;
        BufferedInputStream BIS = null;
        DataInputStream DIS = null;

        try {
            fIS = new FileInputStream(file);
            BIS = new BufferedInputStream(fIS);
            DIS = new DataInputStream(BIS);
            while (DIS.available() != 0) {
                System.out.println(DIS.readLine());
            }
            fIS.close();
            BIS.close();
            DIS.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
