/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anak.del.Tugas1;

import java.util.LinkedList;

/**
 *
 * @author Isabella
 */
public class Tugas1 {

    public static void main(String[] args) {
        LinkedList queue = new LinkedList();
        System.out.println("Warna :");
        queue.addFirst("CYAN");
        queue.addFirst("BLUE");
        queue.addFirst("WHITE");
        queue.addFirst("RED");
        queue.addFirst("MAGENTA");
        System.out.println(queue);

        LinkedList queueAddShow = new LinkedList();
        System.out.println("Warna yang dihapus :");
        queueAddShow.addFirst("BLUE");
        queueAddShow.addFirst("WHITE");
        queueAddShow.addFirst("RED");
        System.out.println(queueAddShow);

        queue.remove(1);
        queue.remove(1);
        queue.remove(1);

        System.out.println("");
        System.out.println("ouput : ");
        System.out.println("warna : ");
        System.out.println(queue);
    }
}
