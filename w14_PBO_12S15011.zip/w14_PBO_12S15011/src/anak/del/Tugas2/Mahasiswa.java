/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anak.del.Tugas2;

/**
 *
 * @author Isabella
 */
public class Mahasiswa implements Comparable<Mahasiswa> {

    String Nrp, Nama;
    float Nilai;

    @Override
    public String toString() {
        return "Mahasiswa dengan " + "Nrp :" + Nrp + ", Nama :" + Nama + ", Nilai : " + Nilai + "";
    }

    public Mahasiswa(String Nrp, String Nama, float Nilai) {
        this.Nrp = Nrp;
        this.Nama = Nama;
        this.Nilai = Nilai;
    }

    @Override
    public int compareTo(Mahasiswa o) {
    if (this.Nilai < o.Nilai) {
            return -1;
        } else if (this.Nilai == o.Nilai) {
            return 0;
        } else {
            return 1;
        }    
    }

        
}
