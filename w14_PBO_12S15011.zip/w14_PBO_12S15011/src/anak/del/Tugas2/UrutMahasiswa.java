/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anak.del.Tugas2;

import java.util.Arrays;

/**
 *
 * @author Isabella
 */
public class UrutMahasiswa {

    public static void main(String[] args) {
        Mahasiswa[] nOrang = {new Mahasiswa("001", "Soni P", 65),
            new Mahasiswa("002", "Saros", 87),
            new Mahasiswa("003", "Yahid Xanggam", 98),
            new Mahasiswa("004", "Zael", 76),
            new Mahasiswa("005", "Yulianthy", 65),
            new Mahasiswa("006", "Yonathan P", 66),
            new Mahasiswa("007", "Yandi", 90),
            new Mahasiswa("008", "Yono", 65),
            new Mahasiswa("009", "Yessi", 72),
            new Mahasiswa("010", "Yassim", 66)
        };
        System.out.println("Data Mahasiswa:");
        for (Mahasiswa x : nOrang) {
            System.out.println(x.toString());
        }

        //urutkan dan tampilkan kembali
        Arrays.sort(nOrang);
        System.out.println("\nData Mahasiswa:");
        for (Mahasiswa x : nOrang) {
            System.out.println(x.toString());
        }
    }
}
