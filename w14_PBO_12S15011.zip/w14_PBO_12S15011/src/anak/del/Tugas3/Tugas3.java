/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anak.del.Tugas3;

import java.util.*;
import java.util.Scanner;

public class Tugas3 {

    public static void main(String[] args) {
        Scanner tugas3 = new Scanner(System.in);
        String teks;
        teks = tugas3.nextLine();
        // Menciptakan TreeMap, menampung kata (kunci) dan  jumlah kemunculan (nilai)
        TreeMap<String, Integer> peta = new TreeMap<String, Integer>();

        String[] kata = teks.split(" ");
        for (int i = 0; i < kata.length; i++) {
            String key = kata[i].toLowerCase();

            if (key.length() > 0) {
                if (peta.get(key) == null) {
                    peta.put(key, 1);
                } else {
                    int nilai = peta.get(key).intValue();
                    nilai++;
                    peta.put(key, nilai);
                }
            }
        }
        Set<Map.Entry<String, Integer>> entrySet = peta.entrySet();
        for (Map.Entry<String, Integer> entry : entrySet) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("Nilai terendah =" + peta.firstKey());
        System.out.println("Nilai Tertinggi = " + peta.lastKey());
    }
}

